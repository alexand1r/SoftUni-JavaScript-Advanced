function createPeopleClasses() {
    return {Employee, Junior, Senior, Manager};
}