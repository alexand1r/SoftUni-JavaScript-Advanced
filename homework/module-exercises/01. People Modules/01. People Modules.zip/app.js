result.Employee = require('./employees/Employee');
result.Junior = require('./employees/Junior');
result.Senior = require('./employees/Senior');
result.Manager = require('./employees/Manager');