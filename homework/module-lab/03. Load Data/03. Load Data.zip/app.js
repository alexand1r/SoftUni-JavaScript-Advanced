let functions = require('./functions');

result.sort = functions.sort;
result.filter = functions.filter;